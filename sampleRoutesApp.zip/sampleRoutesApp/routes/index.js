var express = require('express');
var router = express.Router();


/* GET home page. */
router.get('/', function(req, res, next) {
  if(req.session.page_views){
    if(req.session.page_views > 4){
      req.session.destroy();
      res.send("Session destroyed");
      console.log("im here");
     }else{
      req.session.page_views++;
      res.send("You visited this page " + req.session.page_views + " times");
     } 
 } 
 else {
    req.session.page_views = 1;
    res.send("Welcome for the first time!");
 }
});

module.exports = router;
