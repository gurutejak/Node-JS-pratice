var http = require('http');
var url = require('url');
var express = require('express');
var router = express.Router();
var loginLogic = require('../server/main');
module.exports = router;

router.use(function(req, res, next) {
    console.log("In Middleware");
    next(); 
});

router.get('/login', function(req, res) {
	var queryData = url.parse(req.url, true).query;
	var user_id = req.param('value1');
	var password = req.param('value2');
	res.cookie('username', user_id,{maxAge: 30000 }).send('Cookie saved');
	console.log(user_id);
	console.log("In profile");
});

router.get('/', function(req, res, next) {
  	res.render('../views/home.html');
  	console.log("In Login");
});

router.get('/getCookie', function(req, res, next) {
	res.send(req.cookies.username);
	console.log(eq.cookies);
});

//http://localhost:8080/login?value1=as&value2=as
