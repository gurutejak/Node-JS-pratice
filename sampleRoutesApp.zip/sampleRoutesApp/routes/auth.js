var LocalStrategy = require('passport-local').Strategy;
var passport = require('passport');
var express = require('express');
var router = express.Router();

router.use(function (req, res, next) {
    console.log("In Middleware1");
    next();
});

router.get('/', function (req, res, next) {
    console.log("In Auth");
});

passport.use(new LocalStrategy(
    function (username, password, callback) {
        if(username == "cigna" && password == "12345")
        {
            console.log("1");
            return callback(null, username);
        }
        else{
            console.log("2");
            return callback(err);
        }
    }));

router.get('/authLogin',
    function (req, res) {
        console.log("Im here")
        res.render('../views/home.html');
    });

router.post('/authLogin',
    passport.authenticate('local', { failureRedirect: 'auth/authLogin' }),
    function (req, res) {
        console.log(req.user);
        res.send('login success');
    });

passport.serializeUser(function (user, callback) {
    callback(null, user);
});

passport.deserializeUser(function (id, callback) {
    callback(null, id);
});


module.exports = router;