var express = require('express');
var router = express.Router();
var logic = require('../server/main');
module.exports = router;
/* GET users listing. */

router.use(function(req, res, next) {
    console.log(req.method, req.url);
    next(); 
});

router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.get('/deleteUser:id', function(req, res) {
  res.send('user ' + req.params.id);

  logic.addFunc({value1: 5,value2: 2});

});