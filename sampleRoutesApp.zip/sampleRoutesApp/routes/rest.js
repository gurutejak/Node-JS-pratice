var LocalStrategy = require('passport-local').Strategy;
var passport = require('passport');
var express = require('express');
var router = express.Router();

passport.use(new LocalStrategy(
    function (username, password, callback) {
        if (username == "cigna" && password == "12345") {
            console.log("1");
            return callback(null, username);
        }
        else {
            console.log("2");
            return callback(err);
        }
    }));

router.get('/userLogin',
    function (req, res) {
        console.log("Im here")
        res.render('../views/userLogin.html');
    });

router.post('/restLogin',
    passport.authenticate('local', { failureRedirect: 'auth/restLogin' }),
    function (req, res) {
        console.log(req.user);
        createSession(req);
        res.send('login success');
    });

function createSession(req) {
    if (!req.session.userid) {
        req.session.userid = req.user;
    }
}

router.use(function (req, res, next) {
    console.log(req.user)
    if (!req.user) {
        res.send("You are not an authorized user");
        return;
    }
    console.log('MiddleWare');
    next();
})

router.get('/', function (req, res, next) {
    console.log("Valid user in rest");
    res.send("Valid user in rest");
});

router.get('/logout', function (req, res) {
    // session destroy
    req.session.destroy();
    res.send("Successfully logged out!");
})

// router.delete('/ ', function (req, res){
//     req.session.destroy();
//     res.send("Successfully logged out from delete");
// })

passport.serializeUser(function (user, callback) {
    callback(null, user);
});

passport.deserializeUser(function (id, callback) {
    callback(null, id);
});


module.exports = router;