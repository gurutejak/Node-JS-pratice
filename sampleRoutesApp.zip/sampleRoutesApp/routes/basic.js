var basicStrategy = require('passport-http').BasicStrategy;
var passport = require('passport');
var express = require('express');
var router = express.Router();

router.use(function (req, res, next) {
    console.log("In Middleware");
    next();
});

passport.use(new basicStrategy(
    function(username, password, cb) {
        console.log("i am 2");
        console.log(username);
      return cb(null, username);
  }));


router.get('/basicLogin',
    passport.authenticate('basic', { session: false }),
    function (req, res) {
        console.log("i am 1");
        res.send("Login success");
    });

module.exports = router;