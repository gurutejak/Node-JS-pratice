module.exports  = {
	addFunc : add
}

function add(data, callback){
	if (data.value1 && data.value2) {
		var sum = data.value1 + data.value2;
		console.log(sum)
		callback(null,sum)
	}else{
		console.log("Invalid Entery")
		callback("Invalid Entery")
	}
}